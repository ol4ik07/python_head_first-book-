from setuptools import setup
setup(
name='vsearch',
version='1.0',
description='python search tools',
author='olga',
author_email='rdftg@fcgv.drtf',
py_modules=['vseatch'],
)