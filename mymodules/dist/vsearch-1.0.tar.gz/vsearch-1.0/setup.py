from setuptools import setup
setup(
name='vsearch',
version='1.0',
description='The Head First python search tools',
author='Olga',
author_email='rdftg@fcgv.drtf',
py_modules=['vsearch'],
)